# Paddle-only environment (no Tesseract)

## Local (Windows) — optional install, only if you need it

We recommend using Docker for OCR. If you want to run locally instead, use **Python 3.11** and install only the Paddle extras.

```powershell
# Install Poppler (for pdf2image) — no Tesseract
winget install -e --id oschwartz10612.Poppler

# Add Poppler to PATH for this session
$pop = "$env:LOCALAPPDATA\Programs\poppler-*"
$popPath = (Get-ChildItem $pop -Directory | Sort-Object LastWriteTime -Desc | Select-Object -First 1).FullName + "\Library\bin"
$env:Path += ";" + $popPath

# Use Python 3.11 venv because PaddlePaddle wheels are readily available
py -3.11 -m venv .venv; .\.venv\Scripts\Activate.ps1
python -m pip install -U pip
python -m pip install -e ".[dev,paddle]"
transcript-parser --help
```

> Your script's default flow should work without Tesseract present. If your code references Tesseract conditionally, simply keep `pytesseract` uninstalled; those branches will be skipped.

## Docker (recommended)

```powershell
docker build -f Dockerfile.paddle -t transcript_parser:paddle .
docker run --rm -it -v ${PWD}:/app transcript_parser:paddle transcript-parser --help
```

To process a PDF (adjust flags to your script):
```powershell
docker run --rm -it -v ${PWD}:/app transcript_parser:paddle transcript-parser --subjects math stat --ocr-engine paddle sample.pdf
```

## CI (on demand)

In GitHub → Actions → **Paddle Smoke** → **Run workflow** to confirm that Paddle-only image builds and your CLI runs.
