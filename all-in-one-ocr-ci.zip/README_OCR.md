# OCR Setup (One-Step via Dockerfile.ocr)

**Build OCR-ready image (CPU, PaddleOCR + Tesseract + Poppler):**
```powershell
docker build -f Dockerfile.ocr -t transcript_parser:ocr .
```

**Run your CLI with OCR inside the container (example flags; adjust to your script):**
```powershell
docker run --rm -it -v ${PWD}:/app transcript_parser:ocr transcript-parser --subjects math stat --prefer-ocr sample.pdf
```

**Manual OCR verification in GitHub Actions (on demand):**
- Go to **Actions → OCR Smoke → Run workflow**. This builds `Dockerfile.ocr` and runs `transcript-parser --help` in the container.
